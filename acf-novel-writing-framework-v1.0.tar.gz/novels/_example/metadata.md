# Example Novel - Metadata

**Title**: The Starlight Chronicles
**Author**: [Your Name]
**Genre**: Science Fiction / Light Novel
**Subgenre**: Space Opera
**Target Audience**: Young Adult / Adult
**Setting**: Far future, multiple star systems
**Tone**: Adventurous with serious moments
**Status**: Draft

## Synopsis

A young engineer discovers an ancient alien artifact that unlocks faster-than-light travel, thrusting them into a galactic conflict between rival factions.

## Volumes Planned

- **Volume 1**: Discovery (Chapters 1-10)
- **Volume 2**: Conflict (Chapters 11-20)
- **Volume 3**: Resolution (Chapters 21-30)

## Current Progress

- **Chapters Written**: 0
- **Chapters Accepted**: 0
- **Word Count**: 0
- **Status**: Planning phase

## Notes

This is an example project structure. Replace with your actual novel metadata.

---

**Created**: 2025-11-17
**Last Updated**: 2025-11-17
